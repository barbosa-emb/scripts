#!/bin/bash

cd /home/eduardo/scripts
MESSAGE="Desligando o Servidor: 192.168.3.24 (Duplicati)"
/usr/sbin/qm shutdown 104
./util/send_telegram_message "$MESSAGE"
