#!/bin/bash

cd /home/eduardo/scripts
MESSAGE="Ligando o Servidor: 192.168.3.24 (Duplicati)"
/usr/sbin/qm start 104
./util/send_telegram_message "$MESSAGE"





